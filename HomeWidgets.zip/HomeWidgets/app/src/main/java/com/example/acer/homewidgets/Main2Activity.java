package com.example.acer.homewidgets;

import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class Main2Activity extends AppCompatActivity {
TextView tv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
    tv=findViewById(R.id.textview);
        int position=getIntent().getIntExtra("pos",0);
    String[] detailes=getResources().getStringArray(R.array.details);
    String data=detailes[position];
 tv.setText(data);
        SharedPreferences sharedPreferences=getSharedPreferences("Mypre",MODE_PRIVATE);
        SharedPreferences.Editor editor= sharedPreferences.edit();
        editor.putString("key",data);
        editor.commit();
        Intent i=new Intent(this,NewAppWidget.class);
        i.setAction("android.appwidget.action.APPWIDGET_UPDATE");
        int[] widgets= AppWidgetManager.getInstance(this).getAppWidgetIds(new ComponentName(this,NewAppWidget.class));
    i.putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS,widgets);
    sendBroadcast(i);
    }
}
